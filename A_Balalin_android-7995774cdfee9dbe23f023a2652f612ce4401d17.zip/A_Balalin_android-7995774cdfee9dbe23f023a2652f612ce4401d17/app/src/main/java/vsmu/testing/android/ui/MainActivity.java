package vsmu.testing.android.ui;

import android.app.Activity;
import android.content.Intent;
import android.content.res.TypedArray;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.igalata.bubblepicker.BubblePickerListener;
import com.igalata.bubblepicker.adapter.BubblePickerAdapter;
import com.igalata.bubblepicker.model.BubbleGradient;
import com.igalata.bubblepicker.model.PickerItem;
import com.igalata.bubblepicker.rendering.BubblePicker;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.kyleduo.switchbutton.SwitchButton;

import org.jetbrains.annotations.NotNull;

import vsmu.testing.android.App;
import vsmu.testing.android.R;
import vsmu.testing.android.Utils;
import vsmu.testing.android.database.DBHelper;
import vsmu.testing.android.ui.adapters.DisciplineAdapter;

public class MainActivity extends Activity implements View.OnClickListener {

    //private SlidingMenu mMenu;
    BubblePicker picker;
    PickerItem item;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
        mMenu = new SlidingMenu(this);
        mMenu.setMode(SlidingMenu.LEFT);
        mMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_MARGIN);
        mMenu.setTouchmodeMarginThreshold(Utils.dp2sp(this, 58.0F));
        mMenu.setShadowWidthRes(R.dimen._15sdp);
        mMenu.setShadowDrawable(R.drawable.shadow);
        mMenu.setBehindOffsetRes(R.dimen._53sdp);
        mMenu.setFadeDegree(0.35f);
        mMenu.attachToActivity(this, SlidingMenu.SLIDING_CONTENT);
        mMenu.setMenu(R.layout.main_menu);*/

        picker = findViewById(R.id.picker);
        picker.setBubbleSize(1);
        picker.setCenterImmediately(true);

        /*findViewById(R.id.menu).setOnClickListener(this);
        findViewById(R.id.feedback).setOnClickListener(this);
        findViewById(R.id.visitSite).setOnClickListener(this);
        SwitchButton examSwitch = findViewById(R.id.examSwitch);
        examSwitch.setChecked(App.get().isExam());
        examSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                App.get().setExam(isChecked);
            }
        });*/

        final String[] titles = getResources().getStringArray(R.array.disсipline);
        final TypedArray colors = getResources().obtainTypedArray(R.array.colors);

        picker.setAdapter(new BubblePickerAdapter() {
            @Override
            public int getTotalCount() {
                return titles.length;
            }
            @NotNull
            @Override
            public PickerItem getItem(int position) {
                item = new PickerItem();
                item.setTitle(titles[position]);
                item.setGradient(new BubbleGradient(colors.getColor((position * 2) % 8, 0),
                        colors.getColor((position * 2) % 8 + 1, 0), BubbleGradient.VERTICAL));
                item.setTextColor(ContextCompat.getColor(MainActivity.this, android.R.color.white));
                item.setCustomData(position);
                return item;
            }
        });
        picker.setListener(new BubblePickerListener() {
            @Override
            public void onBubbleSelected(@NotNull PickerItem item) {
                position = (Integer)item.getCustomData();
                DBHelper.getData().openDB(MainActivity.this, position);
                startActivity(new Intent(MainActivity.this, TestingActivity.class).putExtra(TestingActivity.POSITION, position));
                overridePendingTransition(R.anim.in_right, R.anim.out_left);
                Toast.makeText(getApplicationContext(), Integer.toString(position), Toast.LENGTH_LONG).show();
            }
            @Override
            public void onBubbleDeselected(@NotNull PickerItem item) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        picker.onResume();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            /*
            case R.id.menu:
                if(!mMenu.isMenuShowing()) mMenu.showMenu(true);
                break;*/
            case R.id.feedback:
                Utils.sendEmail(MainActivity.this);
                break;
            case R.id.visitSite:
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.site))));
                break;
        }
    }
}